Parallelware Trainer Quickstart
===============================

These examples are well-known microbenchmarks that are representative of algorithms frequently used in scientific applications 
and suitable for parallelizing. They have been chosen to help you get started with using Parallelware Trainer for the 
parallelization of scientific codes using OpenMP and OpenACC directives, serving as a quickstart to give you a tour of the 
different features of Parallelware Trainer.

|Step | Example                            | Description                                    |
|-----|------------------------------------|------------------------------------------------|
|  1  | [PI](PI/README.md)                 | Approximation of the number PI                 |
|  2  | [DOTPRODUCT](DOTPRODUCT/README.md) | Scalar product of two vectors                  |
|  3  | [ATMUX](ATMUX/README.md)           | Sparse Transposed Matrix-Vector Multiplication |

You should start with the [PI](PI/README.md) example, following with [DOTPRODUCT](DOTPRODUCT/README.md) and finishing with [ATMUX](ATMUX/README.md).

Each example takes you through the standard process for using Parallelware Trainer as a learning platform:

1. Opening an existing folder as a project.
2. Identifying opportunities for parallelization and generating a parallel version of one loop.
3. Benchmarking the performance of the serial and parallel code to measure the performance change with newly parallelized code.
4. Creating different versions of the code, parallelizing the same code region but with different parallel methods.
5. Managing the different versions of the same source code file including benchmarking each version.
6. Understanding how to make best use of the suggestions that may follow any parallelization.
7. Specifying code hints that can not be automatically determined.
8. Supplying compiler flags that may be required for analysis.
9. Group several loops for joint parallelization.

More detailed information is available in the user manual, accessible through *Help > Open User Manual*.
