#include <math.h>
#include <stdio.h>
#include <stdlib.h>

double getClock();


double dotproduct(double *u, double *v, int n) {
    double result = 0;

    for (int i = 0; i < n; i++) {
        result += u[i] * v[i];
    }

    return result;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <n>\n", argv[0]);
        printf("  <n> is the desired test size.\n");
        return 1;
    }

    // Reads the test parameters from the command line
    unsigned long N = 0;
    sscanf(argv[1], "%lu", &N);
    printf("- Input parameters\n");
    printf("size\t= %lu\n", N);

    // Vector creation and initialization
    double *U = (double *)malloc(sizeof(double) * N);
    double *V = (double *)malloc(sizeof(double) * N);

    if (!U || !V) {
        free(U);
        free(V);
        printf("Error: not enough memory to run the test using n = %lu\n", N);
        return 1;
    }

    for (int i = 0; i < N; i++) {
        U[i] = rand() % 10;
        V[i] = rand() % 10;
    }

    printf("- Executing test...\n");
    double time_start = getClock();
    // ================================================

    double result = dotproduct(U, V, N);

    // ================================================
    double time_finish = getClock();

    // Prints an execution report
    printf("time (s)= %.6f\n", time_finish - time_start);
    printf("result\t= %.2f\n", result);

    free(U);
    free(V);

    return 0;
}

double getClock() {
#ifdef _OPENMP
#include <omp.h>
    return omp_get_wtime();
#elif __linux__ || __APPLE__
#include <time.h>
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1.0e9;
#else
#include <time.h>
    return (double)clock() / CLOCKS_PER_SEC;
#endif
}
