Example ATMUX: Sparse Transposed Matrix-Vector Multiplication
=============================================================

## Objectives

By the end of this exercise you should know how to:

- [X] Open an existing code directory as a project in Parallelware Trainer.
- [X] Identify opportunities for parallelization and generate a parallel version of one loop.
- [X] Run the newly parallelized code and measure the execution time.
- [X] Create and manage files that contain different parallel implementations of the same loop using different parallelization methods.
- [X] Understand how to make best use of the suggestions that may follow any parallelization.
- [X] Provide information to Parallelware that cannot be automatically determined to improve parallelization.
- [X] Supply compiler flags that may be required to successfully analyze the code.
- [X] Group several loops into a block to parallelize them together.

(This example extends the [PI](../PI/README.md) and [DOTPRODUCT](../DOTPRODUCT/README.md) examples which we recommend completing first.)

## Steps

1. Launch Parallelware Trainer

2. Open the PI code example from the Parallelware Trainer menus (*File > Open Project*). Select the 'PI' folder in the examples directory. This should open the project in the Parallelware Trainer Project Explorer panel.

3. Notice that there are no green circles identifying opportunities for parallelization. If you take a look at the Parallelware output console you will see an error stating that the 'CRSMatrix.h' file was not found. If you were to compile that same source code file using GCC it would give the exact same error: you need to instruct it on where to look for the header files. The same happens when your code require some constant definitions. To make things easier, Parallelware Trainer understands such GCC/Clang flags.

4. Provide the missing analysis flags.
    * Open the Project Configuration dialogue: select the *Project > Configuration* menu option.
    * In the analysis enter the required flag to specify where the headers are located (relative to the project path): `-I lib`.

5. Sometimes it is more efficient to group several loops into the same parallelize region. Parallelware Trainer will detect a curly-braced enclosed block containing several loops as an opportunity.
    * Create a new block enclosing both loops in the 'atmux' function by inserting a new line containing just '{' before line 14 and another one containing '}' before line 23.
    * Save and click the marker that will appear to the left of the opening '{' you've just inserted.
    * Parallelize and notice how a single parallel region now contains both loops.
