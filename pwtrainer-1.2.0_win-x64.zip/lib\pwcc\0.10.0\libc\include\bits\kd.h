#include <linux/kd.h>
